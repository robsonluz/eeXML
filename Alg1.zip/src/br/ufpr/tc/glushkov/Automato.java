/*
 * Created on 05/05/2005
 *
 */
package br.ufpr.tc.glushkov;

/**
 * @author Robson Jo�o Padilha da Luz
 *
 */
public class Automato 
{
	private char[] q;
	private char[] sigma;
	private char si;
	private char f[];
	
}