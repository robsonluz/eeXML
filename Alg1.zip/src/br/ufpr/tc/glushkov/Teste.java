/*
 * Created on 05/05/2005
 *
 */
package br.ufpr.tc.glushkov;

import com.stevesoft.pat.Regex;



/**
 * @author Robson Jo�o Padilha da Luz
 *
 */
public class Teste 
{
	public static void main(String args[])
	{

		try{
			Regex r = new Regex("(\\S)\\+(\\S)=(\\S)","${1} + ${2} = ${3}");
			Regex r1 = new Regex("(\\S)\\+(\\S)","OR(${1}, ${2})");
			System.out.println(r1.replaceAll("a+b"));
			
			r = new Regex("(?m)^","[start]");
			System.out.println(r.replaceAll("a\nb\nc"));
			//System.out.println(r.fir());
		}catch(Exception e){
			e.printStackTrace();
		}
		/*
	    String frase = "E ele disse: 'java'!";
	    Pattern p = Pattern.compile("'(.*?)'");
	    Matcher m = p.matcher(frase);

	    while (m.find()) {
	        // chamada diferente:
	        System.out.println(m.group(1));
	    }
	    */
		
		/*String exp = "a*.b.c+.d;a";
		System.out.println(exp);
		System.out.println("-------------------------");
		Exp e = new Exp(exp);
		Exp[] subs = e.getSubExps();
		for(Exp sub: subs)
		{
			System.out.println(sub);
		}
		
		System.out.println("-------------------------");
		Exp ee = new Exp(exp);
		Common.first(ee);
		*/
		
		//System.out.println(Common.union(new char[]{'a','b'},new char[]{'c'}));
	}
}