/*
 * Created on 21/05/2005
 *
 */
package br.ufpr.tc.glushkov.vs1;

/**
 * @author Robson Jo�o Padilha da Luz
 *
 */
public class Transition 
{
	private String estadoAtual;
	private String transicao;
	private String estadoNovo;
	
	
	public String getEstadoAtual() {
		return estadoAtual;
	}
	public void setEstadoAtual(String estadoAtual) {
		this.estadoAtual = estadoAtual;
	}
	public String getEstadoNovo() {
		return estadoNovo;
	}
	public void setEstadoNovo(String estadoNovo) {
		this.estadoNovo = estadoNovo;
	}
	public String getTransicao() {
		return transicao;
	}
	public void setTransicao(String transicao) {
		this.transicao = transicao;
	}
}