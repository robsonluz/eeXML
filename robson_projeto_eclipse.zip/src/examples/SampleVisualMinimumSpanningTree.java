package examples;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
import java.io.*;
import salvo.jesus.graph.*;
import salvo.jesus.graph.algorithm.*;
import salvo.jesus.graph.visual.*;
import salvo.jesus.graph.visual.drawing.*;
import salvo.jesus.graph.visual.layout.*;


/**
 * A sample application demonstrating the minimum spanning tree algorithm.
 * For the sample below, the total weights of the edges in the minimum
 * spanning tree must be 16.
 *
 * Each run of this application may produce a different minimum spanning
 * tree, but the result will still satisfy the definition of a minimum
 * spanning tree. The total weight of all the edges in the minimum
 * spanning tree will and should always be 16 (unless you modify the code).
 *
 * The weighted graph created here is taken from the book "Algorithms"
 * by Robert Sedgewick, 1988, page 459.
 *
 *
 * @author  Jesus M. Salvo Jr.
 */

public class SampleVisualMinimumSpanningTree extends JFrame {
    WeightedGraph	wgraph;
    WeightedGraph   subGraph;
    VisualGraph     vgraph;
    Vertex	v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13;

    public SampleVisualMinimumSpanningTree() throws Exception {
        GraphEditor         editor;
        GraphLayoutManager  layoutManager;

        // Initialise the weighted graph
        this.initGraph();

        // Get a VisualGraph
        editor = new GraphEditor();
        editor.setGraph( wgraph );
        vgraph = editor.getVisualGraph();

        // Create an instance of an alternate paitner for the edges
        AlternateVisualEdgePainter newEdgePainter = new AlternateVisualEdgePainter();

        // Use the alternate painter only for a subgraph of the weighted graph,
        // in particular for the minimum spanning tree of the weighted graph
        subGraph = wgraph.minimumSpanningTree();
        vgraph.emphasizeSubGraph( subGraph,
            null, null, null, newEdgePainter );

        System.out.println( "Weighted Graph:" );
        System.out.println( wgraph );
        System.out.println();

        System.out.println( "Minimum Spanning Tree: " );
        System.out.println( subGraph );

        // Force the layout of the vertices to be similar to that in the book
        this.forceLayout( vgraph );

        // Initialise a layout manager, though not really part of this eample
        layoutManager = new StraightLineLayout( editor.getVisualGraph() );
        editor.setGraphLayoutManager( layoutManager );

        // Make it all visible
        this.getContentPane().setLayout( new GridLayout(1,2));
        this.getContentPane().add( editor );

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = new Dimension( screenSize.width - 80, screenSize.height - 80 );

        this.setSize( frameSize );
        this.setLocation((int)(screenSize.getWidth() - frameSize.getWidth()) / 2, (int)(screenSize.getHeight() - frameSize.getHeight()) / 2);

        // Terminate the application when the window closes
        this.addWindowListener(new WindowAdapter() {
          public void windowClosing(WindowEvent e) { System.exit(0); }
          });

    }

    private void initGraph() throws Exception {
        wgraph = new WeightedGraphImpl();

        v1 = new VertexImpl( "A" );
        v2 = new VertexImpl( "B" );
        v3 = new VertexImpl( "C" );
        v4 = new VertexImpl( "D" );
        v5 = new VertexImpl( "E" );
        v6 = new VertexImpl( "F" );
        v7 = new VertexImpl( "G" );
        v8 = new VertexImpl( "H" );
        v9 = new VertexImpl( "I" );
        v10 = new VertexImpl( "J" );
        v11 = new VertexImpl( "K" );
        v12 = new VertexImpl( "L" );
        v13 = new VertexImpl( "M" );

        wgraph.add( v1 );
        wgraph.add( v2 );
        wgraph.add( v3 );
        wgraph.add( v4 );
        wgraph.add( v5 );
        wgraph.add( v6 );
        wgraph.add( v7 );
        wgraph.add( v8 );
        wgraph.add( v9 );
        wgraph.add( v10 );
        wgraph.add( v11 );
        wgraph.add( v12 );
        wgraph.add( v13 );

        wgraph.addEdge( v1, v2, 1.0 );
        wgraph.addEdge( v1, v6, 2.0 );
        wgraph.addEdge( v1, v7, 6.0 );
        wgraph.addEdge( v2, v3, 1.0 );
        wgraph.addEdge( v2, v4, 2.0 );
        wgraph.addEdge( v2, v5, 4.0 );
        wgraph.addEdge( v3, v5, 4.0 );
        wgraph.addEdge( v4, v5, 2.0 );
        wgraph.addEdge( v4, v6, 1.0 );
        wgraph.addEdge( v6, v5, 2.0 );
        wgraph.addEdge( v7, v5, 1.0 );
        wgraph.addEdge( v7, v8, 3.0 );
        wgraph.addEdge( v8, v9, 2.0 );
        wgraph.addEdge( v9, v11, 1.0 );
        wgraph.addEdge( v11, v10, 1.0 );
        wgraph.addEdge( v10, v12, 3.0 );
        wgraph.addEdge( v10, v13, 2.0 );
        wgraph.addEdge( v7, v10, 1.0 );
        wgraph.addEdge( v12, v13, 1.0 );
        wgraph.addEdge( v12, v7, 5.0 );
        wgraph.addEdge( v12, v5, 4.0 );
        wgraph.addEdge( v12, v6, 2.0 );
    }

    private void forceLayout( VisualGraph vgraph ) {
        vgraph.getVisualVertex( v1 ).setLocation( 50, 50 );
        vgraph.getVisualVertex( v2 ).setLocation( 150, 150 );
        vgraph.getVisualVertex( v3 ).setLocation( 250, 150 );
        vgraph.getVisualVertex( v4 ).setLocation( 150, 250 );
        vgraph.getVisualVertex( v5 ).setLocation( 250, 250 );
        vgraph.getVisualVertex( v6 ).setLocation( 50, 350 );

        vgraph.getVisualVertex( v7 ).setLocation( 350, 150 );

        vgraph.getVisualVertex( v8 ).setLocation( 450, 50 );
        vgraph.getVisualVertex( v9 ).setLocation( 550, 50 );
        vgraph.getVisualVertex( v10 ).setLocation( 450, 250 );
        vgraph.getVisualVertex( v11 ).setLocation( 550, 250 );
        vgraph.getVisualVertex( v12 ).setLocation( 450, 350 );
        vgraph.getVisualVertex( v13 ).setLocation( 550, 350 );
    }


    public static void main( String args[] ) throws Exception {
        SampleVisualMinimumSpanningTree frame = new SampleVisualMinimumSpanningTree();

        frame.setTitle( "Sample Visual Minimum Spanning Tree" );
        frame.setVisible( true );

        JOptionPane.showMessageDialog( frame,
            "This demonstrates a custom VisualEdgePainter\n" +
            "to paint the minimum spanning tree of the displayed graph.\n" +
            "Rerunning the demo several times may yield a different,\n" +
            "but still legal minimum spanning tree." );
    }
}

