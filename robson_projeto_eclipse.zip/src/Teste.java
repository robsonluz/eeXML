import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/*
 * Created on 07/06/2005
 *
 */

/**
 * @author Robson Jo�o Padilha da Luz
 *
 */
public class Teste 
{
	public static void main(String args[])
	{
		String teste[] = new String[]{"elemento1","elemento2"};
		for(int i=0;i<teste.length;i++)
		{
			String x = teste[i];
			System.out.println(x);
		}
		
		for(String x: teste)
		{
			System.out.println(x);
		}
		
		List<String> lst = new LinkedList();
		
		
		lst.add("teste");
		lst.add("teste");
		lst.add("teste");
		
		Iterator it = lst.iterator();
		while(it.hasNext())
		{
			String x = (String) it.next();
			System.out.println(x);
		}
		
		for(String x: lst)
		{
			System.out.println(x);
		}
		
		
	}
}
